import type { Metadata } from "next";import "./globals.css";import { Header } from "@/components/Header";
export const metadata:Metadata={title:"Paraísos Perdidos",description:"Editorial digital de literatura lenta."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="es"><body className="font-serif"><Header/>{children}</body></html>}
